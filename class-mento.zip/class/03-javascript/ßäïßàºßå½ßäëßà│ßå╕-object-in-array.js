const profiles = [
    { name: "철수", age: 8, school: "다람쥐초등학교" },
    { name: "영희", age: 11, school: "공룡초등학교" },
    { name: "훈이", age: 13, school: "거북이초등학교" }
]
// undefined
profiles.length
// 3
profiles[1]
// {name: '영희', age: 11, school: '공룡초등학교'}age: 11name: "영희"school: "공룡초등학교"[[Prototype]]: Object
profiles[1].school
// '공룡초등학교'