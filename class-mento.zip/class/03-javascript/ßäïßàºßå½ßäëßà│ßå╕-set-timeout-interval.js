setTimeout(function(){ 
    console.log("기능이 실행!!!") 
}, 2000)
// 2
setInterval(function(){
    console.log("안녕하세요!!")
}, 1000)
// 3